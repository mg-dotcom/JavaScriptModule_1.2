/**
 * Task description: Write a method that returns a deep array like [[key, value]]
 * Expected Result: ({ a: 1, b: 2 }) => [['a', 1], ['b', 2]]
 * Task complexity: 1 of 5
 * @param {Object} object - Any object to transform into array
 * @returns {Array} - a deep array
 */
// export const makePairs = (object) => Object.entries(object)

const kvArray = [
  { key: 1, value: 10 },
  { key: 2, value: 20 },
  { key: 3, value: 30 },
];

const reformattedArray = kvArray.map(({ key, value }) => ({[key] : value}));
const makePairs = (object) => Object.keys(object).map((el) => [el,object[el],])

console.log(makePairs({ a: 1, b: 2 }))

console.log(reformattedArray); // [{ 1: 10 }, { 2: 20 }, { 3: 30 }]

