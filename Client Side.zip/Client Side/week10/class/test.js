let e = ["fsdf","fsfd"]
const [firstElement, secondElement] = e;
console.log()