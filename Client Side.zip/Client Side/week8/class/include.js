
const animals = ['ant', 'dogs', 'cats', 'bird']
const message = 'Practices make perfect'

//string includes - includes substring (case sensitive)
console.log(message.includes('ice')) //true
console.log(message.includes('make')) //true
//array includes - includes string in array elements (case sensitive)
console.log(animals.includes('ats')) //false
console.log(animals.includes('cats')) //true

