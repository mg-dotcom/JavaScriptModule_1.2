function ProductManagement() {
  let products = [
    // {
    // id: 1,
    // name: 'Laptop',
    // category: 'Electronics',
    // price: 88.99,
    // },
    // {
    // id: 2,
    // name: 'Hair Drying',
    // category: 'Electronics',
    // price: 51,  
    // },
    // {
    // id: 3,
    // name: 'Air Condition',
    // category: 'Electronics',
    // price: 58.99
    // }
  ]

  function getAllProducts() {
      return products
  }

  function addProduct(product) {
    if (product !== null) {
      products.push(product);
      return products;
    } else {
      return {};
    }
  }

  function searchByName(name) {
    const nameInsensitive = name.toLowerCase();
    // map เอาหมด , filter เลือกมา specific
    const filteredProducts = products.filter((product) => product.name.toLowerCase().match(nameInsensitive));
    return filteredProducts;
  }

  function searchByPriceRange(minPrice, maxPrice) {
    const range = products.filter((product) => minPrice <= product.price && product.price <= maxPrice)
    return range
  }

  function removeAll() {
   products.splice(0,products.length)
  }

  return {
    removeAll,
    searchByName,
    searchByPriceRange,
    getAllProducts,
    addProduct
  }
}

module.exports = ProductManagement
const productCatalog = ProductManagement()
