let name ={
    firstname: "Apisara"
}
function hey(nameObj){

    const key1 = Object.keys(nameObj);
}

console.log(hey(name));